package com.fingerrehab.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import com.fingerrehab.R;
import com.fingerrehab.model.UserProfile;
import com.fingerrehab.repository.RehabRepository;

/** 首次引导与可编辑本地档案；不收集身份号码或网络账户。 */
public class ProfileActivity extends Activity {
  private RehabRepository repository;
  private UserProfile profile;
  private boolean guide;
  private EditText nickname, age, goal, daily;
  private Spinner hand;

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    repository = RehabRepository.get(this);
    profile = repository.getProfile();
    guide = profile == null && (state == null || state.getBoolean("guide", true));
    if (guide) showGuide();
    else showForm(state);
  }

  private void showGuide() {
    guide = true;
    LinearLayout content = Ui.screen(this, "欢迎使用");
    Ui.gap(content, 26);
    TextView mark = Ui.bold(this, "＋", 64, Ui.BLUE);
    mark.setGravity(17);
    Ui.add(content, mark);
    Ui.gap(content, 20);
    Ui.title(content, "让每一次练习\n都有迹可循", "指尖康复 · " + getString(R.string.app_english_name));
    LinearLayout card = Ui.card(this);
    Ui.add(card, Ui.bold(this, "从指尖开始，记录自己的节奏", 19, Ui.INK));
    Ui.gap(card, 14);
    Ui.add(
        card,
        Ui.text(this, "01  描绘路径，练习稳定控制\n\n02  点击目标，记录反应与协调\n\n03  查看趋势，制定每日小目标", 16, Ui.MUTED));
    Ui.add(content, card);
    Ui.add(
        content,
        Ui.text(
            this, "本应用用于课程设计与辅助训练。评分是软件定义的工程指标，不能诊断疾病或替代专业康复治疗。训练不适时请停止，并咨询专业人员。", 13, Ui.MUTED));
    Ui.gap(content, 24);
    Button start = Ui.button(this, "创建我的本地档案");
    Ui.add(content, start);
    start.setOnClickListener(
        v -> {
          guide = false;
          showForm(null);
        });
  }

  private void showForm(Bundle state) {
    guide = false;
    LinearLayout content = Ui.screen(this, profile == null ? "创建个人档案" : "编辑个人档案");
    Ui.title(content, "认识你的训练目标", "资料与训练记录仅保存在本机");
    LinearLayout form = Ui.card(this);
    nickname = field(form, "昵称 *", "例如：小林", InputType.TYPE_CLASS_TEXT);
    age = field(form, "年龄（选填）", "1～120", InputType.TYPE_CLASS_NUMBER);
    Ui.add(form, Ui.text(this, "惯用手", 14, Ui.MUTED));
    hand = new Spinner(this);
    hand.setAdapter(
        new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, new String[] {"右手", "左手", "双手"}));
    hand.setMinimumHeight(Ui.dp(this, 52));
    Ui.add(form, hand);
    Ui.gap(form, 12);
    goal = field(form, "训练目标 *", "例如：建立规律的手指练习习惯", InputType.TYPE_CLASS_TEXT);
    daily = field(form, "每日目标次数 *", "1～20", InputType.TYPE_CLASS_NUMBER);
    Ui.add(content, form);
    if (profile != null) {
      nickname.setText(profile.nickname);
      age.setText(profile.age == null ? "" : profile.age.toString());
      goal.setText(profile.goal);
      daily.setText(String.valueOf(profile.dailyGoal));
      hand.setSelection("左手".equals(profile.hand) ? 1 : "双手".equals(profile.hand) ? 2 : 0);
    } else {
      daily.setText("3");
      goal.setText("提升手指运动的稳定与协调");
    }
    if (state != null) {
      nickname.setText(state.getString("nickname", nickname.getText().toString()));
      age.setText(state.getString("age", age.getText().toString()));
      goal.setText(state.getString("goal", goal.getText().toString()));
      daily.setText(state.getString("daily", daily.getText().toString()));
      hand.setSelection(state.getInt("hand", 0));
    }
    Button save = Ui.button(this, "保存档案");
    Ui.add(content, save);
    save.setOnClickListener(v -> save());
    Ui.gap(content, 16);
    Ui.add(content, Ui.text(this, "每日次数是个人练习目标，训练计划可另外指定模式。请根据自身情况和专业建议合理安排。", 13, Ui.MUTED));
  }

  private EditText field(LinearLayout box, String label, String hint, int input) {
    Ui.add(box, Ui.text(this, label, 14, Ui.MUTED));
    EditText edit = new EditText(this);
    edit.setTextSize(16);
    edit.setSingleLine(true);
    edit.setHint(hint);
    edit.setInputType(input);
    edit.setMinimumHeight(Ui.dp(this, 52));
    Ui.add(box, edit);
    Ui.gap(box, 12);
    return edit;
  }

  private void save() {
    String name = nickname.getText().toString().trim(), target = goal.getText().toString().trim();
    if (name.isEmpty() || name.length() > 24) {
      nickname.setError("请输入1～24字昵称");
      return;
    }
    if (target.isEmpty() || target.length() > 120) {
      goal.setError("请输入1～120字训练目标");
      return;
    }
    Integer years = null;
    int dailyGoal;
    try {
      String a = age.getText().toString().trim();
      if (!a.isEmpty()) {
        years = Integer.parseInt(a);
        if (years < 1 || years > 120) throw new NumberFormatException();
      }
    } catch (NumberFormatException ex) {
      age.setError("请输入1～120，或留空");
      return;
    }
    try {
      dailyGoal = Integer.parseInt(daily.getText().toString().trim());
      if (dailyGoal < 1 || dailyGoal > 20) throw new NumberFormatException();
    } catch (NumberFormatException ex) {
      daily.setError("请输入1～20");
      return;
    }
    if (profile == null) profile = new UserProfile();
    profile.nickname = name;
    profile.age = years;
    profile.hand = hand.getSelectedItem().toString();
    profile.goal = target;
    profile.dailyGoal = dailyGoal;
    try {
      repository.saveProfile(profile);
      Toast.makeText(this, "档案已保存在本机", Toast.LENGTH_SHORT).show();
      finish();
    } catch (RuntimeException ex) {
      new AlertDialog.Builder(this)
          .setTitle("档案未保存")
          .setMessage("保存失败，请检查设备存储空间后重试。")
          .setPositiveButton("知道了", null)
          .show();
    }
  }

  @Override
  protected void onSaveInstanceState(Bundle out) {
    super.onSaveInstanceState(out);
    out.putBoolean("guide", guide);
    if (!guide && nickname != null) {
      out.putString("nickname", nickname.getText().toString());
      out.putString("age", age.getText().toString());
      out.putString("goal", goal.getText().toString());
      out.putString("daily", daily.getText().toString());
      out.putInt("hand", hand.getSelectedItemPosition());
    }
  }

  @Override
  public void onBackPressed() {
    if (profile == null) {
      if (!guide) showGuide();
      else finishAffinity();
    } else super.onBackPressed();
  }
}
